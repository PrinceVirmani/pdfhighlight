(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_f223ba9c._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_f223ba9c._.js",
  "chunks": [
    "static/chunks/node_modules_pdfjs-dist_build_pdf_5e5dd1fa.js",
    "static/chunks/node_modules_@react-pdf-viewer_core_lib_726c1366._.js",
    "static/chunks/node_modules_next_dist_compiled_ec215a1b._.js",
    "static/chunks/src_906c3dc1._.js",
    "static/chunks/node_modules_@react-pdf-viewer_core_lib_styles_index_ffaeb669.css"
  ],
  "source": "dynamic"
});
